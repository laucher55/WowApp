package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SobreActivity extends AppCompatActivity {

    ImageView btnImg;
    TextView userAbout;

    private final static String PREFERENCES = "preferencias";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);

        userAbout = findViewById(R.id.userAbout);

        btnImg = findViewById(R.id.gotoHomeAbout);

        SharedPreferences preferences = getSharedPreferences(PREFERENCES, 0);
        String nome = preferences.getString("nome", "Usuário não definido");

        if(!nome.equals("Usuário não definido")){
            userAbout.setText(nome + ", espero que goste da expansão Dragonflight");
        } else {
            userAbout.setText("Espero que goste da expansão Dragonflight");
        }
    }

    public void gotoHomeAbout(View view){
        finish();
    }
}