package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView welcomeTxt;
    private final static String PREFERENCES = "preferencias";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        welcomeTxt = findViewById(R.id.txt);

        SharedPreferences preferences = getSharedPreferences(PREFERENCES, 0);
        String nome = preferences.getString("nome", "Usuário não definido");

        if(!nome.equals("Usuário não definido")){
            welcomeTxt.setText(nome + ", seja bem vindo!");
        }else{
            welcomeTxt.setText("Seja bem vindo!");
        }

    }

    @Override
    public void onResume(){
        super.onResume();

        setContentView(R.layout.activity_main);

        welcomeTxt = findViewById(R.id.txt);

        SharedPreferences preferences = getSharedPreferences(PREFERENCES, 0);
        String nome = preferences.getString("nome", "Usuário não definido");

        if(!nome.equals("Usuário não definido")){
            welcomeTxt.setText(nome + ", seja bem vindo!");
        }else{
            welcomeTxt.setText("Seja bem vindo!");
        }
    }

    public void abreSobre(View view){
        Intent i = new Intent(MainActivity.this, SobreActivity.class);
        startActivity(i);
    }

    public void abreLogin(View view){
        Intent i = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(i);
    }



}