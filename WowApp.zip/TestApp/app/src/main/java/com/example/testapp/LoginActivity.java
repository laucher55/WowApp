package com.example.testapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    Button btGravar;
    EditText editNome;
    EditText editEmail;
    TextView txtNome;
    TextView txtEmail;
    ImageView btnImg;
    private final static String PREFERENCES = "preferencias";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        btGravar = findViewById(R.id.buttonGravar);
        editNome = findViewById(R.id.editNome);
        txtNome = findViewById(R.id.txtNome);

        editEmail = findViewById(R.id.editEmail);
        txtEmail = findViewById(R.id.txtEmail);

        btnImg = findViewById(R.id.gotoHomeLogin);

        btGravar.setOnClickListener((v)->{
            SharedPreferences preferences = getSharedPreferences(PREFERENCES, 0);
            SharedPreferences.Editor editor = preferences.edit();

            if(editNome.getText().toString().equals("") && editEmail.getText().toString().equals("")){
               Toast.makeText(getApplicationContext(), "Nome ou Email não foi preenchido", Toast.LENGTH_SHORT).show();
            }else{
                String nome = editNome.getText().toString();
                String email = editEmail.getText().toString();
                editor.putString("nome", nome);
                editor.putString("email", email);
                editor.commit();
                txtNome.setText("Olá " + nome);
                txtEmail.setText("Seu email é: " + email);
                Toast.makeText(getApplicationContext(), "Nome e Email salvo em SharedPreferences", Toast.LENGTH_SHORT).show();
            }


        });

        SharedPreferences preferences = getSharedPreferences(PREFERENCES, 0);
        String nome = preferences.getString("nome", "Usuário não definido");
        String email = preferences.getString("email", "Email de usuário não definido");

        txtNome.setText("Olá " + nome);
        txtEmail.setText("Seu email é: " + email);

    }

    public void gotoHomeLogin(View view){
        finish();
    }

}